package com.tic.app.service;

import com.tic.app.entities.User;

public interface UserService {
    User createUser(User user);
}

