package com.tic.app.controllers;

import java.util.Collections;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.tic.app.entities.User;
import com.tic.app.exceptions.EmailAlreadyExistsException;
import com.tic.app.exceptions.InvalidEmailFormatException;
import com.tic.app.exceptions.InvalidPasswordFormatException;
import com.tic.app.service.UserService;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api")
@Validated
public class UserController {
    @Autowired
    private final UserService userService;
    
    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/bienvenida")
    public ResponseEntity<?> inicio() {
    	return new ResponseEntity<>(Collections.singletonMap("mensaje", "Bienvenidos al Desafío en Spring Boot"), HttpStatus.OK);
    }
    
    @PostMapping("/crear-usuario")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        Pattern patternEmail = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        
        
        /*Contraseña de 4 a 32 caracteres que requiere al menos 3 de 4 (mayúsculas
        y letras minúsculas, números y caracteres especiales) y como máximo
        2 caracteres consecutivos iguales.*/
        Pattern patternPassword = Pattern
        		.compile(
                "^(?:(?=.*\\d)(?=.*[A-Z])(?=.*[a-z])|" +
                "(?=.*\\d)(?=.*[^A-Za-z0-9])(?=.*[a-z])|" +
                "(?=.*[^A-Za-z0-9])(?=.*[A-Z])(?=.*[a-z])|" +
                "(?=.*\\d)(?=.*[A-Z])(?=.*[^A-Za-z0-9]))(?!.*(.)\\1{2,})" +
                "[A-Za-z0-9!~<>,;:_=?*+#.\"&§%°()\\|\\[\\]\\-\\$\\^\\@\\/]" +
                "{8,32}$");
 
        try {
        	Matcher matcher = patternEmail.matcher(user.getEmail());
            if (matcher.find() != true) {
            	throw new InvalidEmailFormatException("El email ingresado es inválido.");
            }
            
            matcher=patternPassword.matcher(user.getPassword());
            if (matcher.find() != true) {
            	throw new InvalidPasswordFormatException("La Contraseña debe tener de 4 a 32 caracteres que requiere al menos 3 de 4 (mayúsculas y letras minúsculas, números y caracteres especiales) y como máximo 2 caracteres consecutivos iguales.");
            }            
        	
            User createdUser = userService.createUser(user);
            return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
        } catch (EmailAlreadyExistsException e) {
            return new ResponseEntity<>(Collections.singletonMap("mensaje", "El correo ya está registrado"), HttpStatus.BAD_REQUEST);
        } catch (InvalidEmailFormatException | InvalidPasswordFormatException e) {
            return new ResponseEntity<>(Collections.singletonMap("mensaje", e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }
}