package com.tic.app.exceptions;

import java.util.Collections;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class RestExceptionHandler {
    @ExceptionHandler({EmailAlreadyExistsException.class, InvalidEmailFormatException.class, InvalidPasswordFormatException.class})
    public ResponseEntity<?> handleBadRequest(Exception ex) {
        return new ResponseEntity<>(Collections.singletonMap("mensaje", ex.getMessage()), HttpStatus.BAD_REQUEST);
    }
}
