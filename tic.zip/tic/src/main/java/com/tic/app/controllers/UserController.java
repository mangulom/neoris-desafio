package com.tic.app.controllers;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tic.app.entities.User;
import com.tic.app.exceptions.EmailAlreadyExistsException;
import com.tic.app.exceptions.InvalidEmailFormatException;
import com.tic.app.exceptions.InvalidPasswordFormatException;
import com.tic.app.service.UserService;


@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/bienvenida")
    public ResponseEntity<?> inicio() {
    	return new ResponseEntity<>(Collections.singletonMap("mensaje", "Bienvenidos al Desafío en Spring Boot"), HttpStatus.OK);
    }
    
    @PostMapping("/crear-usuario")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            User createdUser = userService.createUser(user);
            return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
        } catch (EmailAlreadyExistsException e) {
            return new ResponseEntity<>(Collections.singletonMap("mensaje", "El correo ya está registrado"), HttpStatus.BAD_REQUEST);
        } catch (InvalidEmailFormatException | InvalidPasswordFormatException e) {
            return new ResponseEntity<>(Collections.singletonMap("mensaje", e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }
}